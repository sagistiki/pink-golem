#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec3 pos = Position;
#if defined(IS_GUI)
    // ClawdBlock minimap: glyphs whose colour carries the marker are moved from the centred bossbar title to the
    // top-left corner; map cells (B&3 == 3) are widened by 1 px to close the bitmap glyph spacing.
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    if ((c.r & 3) == 1 && (c.g & 3) == 2 && ((c.b & 3) == 3 || (c.b & 3) == 1)) {
        float guiW = 2.0 / ProjMat[0][0];
        pos.x += 6.0 - (guiW * 0.5 - 48.0 * 0.5);
        if ((c.b & 3) == 3) {
            int v = gl_VertexID % 4;
            if (v == 2 || v == 3) pos.x += 1.0;
        }
    }
    // HUD toolkit (build_pack.py in resourcepacks/hud): glyphs marked R&3 == 1, G&3 == 2, B&3 == 0 (row 0) or 2
    // (row 1) come from a HUD bossbar title whose total advance is 0 (it starts at x = guiWidth / 2). Every HUD glyph
    // lies in the band y = 2..20 of its bossbar slot and slots are 19 px apart, so the slot k comes from the glyph's
    // own y. Bit 2 of R, G, B = the anchor 0..7. The glyph keeps its x/y inside the element and moves to the anchor.
    if ((c.r & 3) == 1 && (c.g & 3) == 2 && ((c.b & 3) == 0 || (c.b & 3) == 2)) {
        float hudW = 2.0 / ProjMat[0][0];
        float hudH = abs(2.0 / ProjMat[1][1]);
        float k = floor((pos.y - 2.0 + 0.5) / 19.0);
        float lx = pos.x - floor(hudW * 0.5 + 0.01);
        float ly = pos.y - 2.0 - 19.0 * k + ((c.b & 3) == 2 ? 18.0 : 0.0);
        int a = ((c.r >> 2) & 1) | (((c.g >> 2) & 1) << 1) | (((c.b >> 2) & 1) << 2);
        vec4 A = vec4(0.0, 6.0, 0.0, 68.0);   // 0 top_left
        if (a == 1) A = vec4(0.5, 0.0, 0.0, 3.0);   // 1 top_centre
        if (a == 2) A = vec4(1.0, -6.0, 0.0, 6.0);   // 2 top_right
        if (a == 3) A = vec4(0.5, 0.0, 1.0, -112.0);   // 3 bottom_centre
        if (a == 4) A = vec4(1.0, -6.0, 1.0, -42.0);   // 4 bottom_right
        if (a == 5) A = vec4(0.0, 6.0, 1.0, -42.0);   // 5 bottom_left
        if (a == 6) A = vec4(0.0, 6.0, 0.5, -18.0);   // 6 middle_left
        if (a == 7) A = vec4(1.0, -6.0, 0.5, -18.0);   // 7 middle_right
        pos.x = floor(A.x * hudW + 0.01) + A.y + lx;
        pos.y = floor(A.z * hudH + 0.01) + A.w + ly;
    }
#endif
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}
