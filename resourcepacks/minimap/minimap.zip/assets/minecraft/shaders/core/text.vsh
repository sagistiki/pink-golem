#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec3 pos = Position;
#if defined(IS_GUI)
    // Pink Golem minimap: glyphs whose colour carries the marker are moved from the centred bossbar title to the
    // top-left corner; map cells (B&3 == 3) are widened by 1 px to close the bitmap glyph spacing.
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    if ((c.r & 3) == 1 && (c.g & 3) == 2 && ((c.b & 3) == 3 || (c.b & 3) == 1)) {
        float guiW = 2.0 / ProjMat[0][0];
        pos.x += 6.0 - (guiW * 0.5 - 48.0 * 0.5);
        if ((c.b & 3) == 3) {
            int v = gl_VertexID % 4;
            if (v == 2 || v == 3) pos.x += 1.0;
        }
    }
#endif
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}
